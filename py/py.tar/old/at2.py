#!/usr/bin/env python
#
# Programa para formatear las tablas html automaticamente
#
import string
import sys

TABLA="/tmp/REPT.htmap"

f = open(TABLA,"r")
lineas = f.readlines()   
f.close()

i = 0
for l in lineas:
   v = string.split(l,"|")
   clave        = string.strip(v[0])
   nombre       = string.strip(v[1])
   programa     = string.strip(v[2])
   periodicidad = string.strip(v[3])
   directorio   = string.strip(v[4])
   categoria    = string.strip(v[5])
   prioridad    = string.strip(v[6])
   if categoria == sys.argv[1]:
      if ( periodicidad == "W" ): periodicidad = "S"
      print '   reps[%2d]=new Rep("%s","%s","%s","%s","%s","%s");' % ( i, categoria, nombre, directorio, periodicidad, prioridad, programa )
      i = i + 1
print "   reps = new Array(%s);" % (i)
