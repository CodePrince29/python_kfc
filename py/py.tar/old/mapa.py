#!/usr/bin/env python
#
# mapa.py
#
import string

tabla="/home/httpd/cgi-bin/py2/repmapa.txt"

def getMapa(mapafile=tabla):
   f = open(mapafile)
   lineas = f.readlines()
   f.close
   mapa = []
   for k in lineas:
      mapa.append( map(string.strip, string.split(k,",") ) )
   return mapa
         
#mymap = getMapa("repmapa2.txt")
#for j in mymap:
#   print j
