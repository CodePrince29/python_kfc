#! /usr/bin/env python
#  Ya no pide nombre del usuario. Simplemente procesa los mensajes
#	7/31/96	  J. Strout		http://www.strout.net/
#   2/28/2000 Miguel Angel Zavaleta

# import needed modules:

from socket import *		# get sockets, for well, sockets
import string				# string functions
import time					# for sleep(1) function
import os
import scan
import fmt

# define global variables
REPDIR="/usr/fms/op/rpts/"
REPFTP="/home/httpd/html/rpts/"
HOST = '192.168.101.254' # Symbolic name meaning the local host
PORT = 4000				# Arbitrary non-privileged server
endl = "\r\n"			# standard terminal line ending

done = 0				# set to 1 to shut this down

kAskName = 0			# some constants used to flag
kOK = 2

def procesa_file( filename, fecha ):
   fmtfile  = REPDIR + filename + "/" + filename + ".fmt"
   datafile = REPDIR + filename + "/" + fecha
   csvfile  = REPFTP + filename + "/" + fecha + ".csv"
   
   fmts = fmt.leer_fileFmt(fmtfile)
   datos = scan.scan_file( datafile, fmts )
   scan.datos_tofile( csvfile, datos )
   return csvfile
   

def HandleMsg(conn, msg):
	print "Handling message: ",msg
		
	# check for commands
	if msg == "quit":
		conn.close()
		return

	if msg[0:5] == "excel":
		# Ejecuta el comando pedido
		n = os.fork()
		if (n == 0 ): 
			newname = msg[6:]
			v1 = string.split(newname,'/')
			filename, p_dia = v1
			csvfile = procesa_file( filename, p_dia )
			print "abriendo en excel: "+ csvfile
			#os.execl("/usr/bin/gnumeric","/usr/bin/gnumeric", csvfile )
			os.execl("/usr/local/Office51/bin/soffice","/usr/local/Office51/bin/soffice", csvfile )
		return


	print "Message no valido: ",msg
	conn.send(" comando no valido: " + msg+ endl )


# MAIN PROGRAM


# set up the server

s = socket(AF_INET, SOCK_STREAM)
s.bind(HOST, PORT)
s.setblocking(0)
s.listen(1)
print "Waiting for connection(s)..."

# loop until done, handling connections and incoming messages

while not done:
	time.sleep(1)		# sleep to reduce processor usage
	try:
		conn, addr = s.accept()
		print "Connection from", addr
		data = conn.recv(1024)
		if not data: 
			break
		data = filter(lambda x: x>=' ' and x<='z', data) 
		data = string.strip(data)
		if data == "shutdown": 
			print "Recibi un shutdown, adios"
			done = 1
		else: 
			HandleMsg(conn, data) 
		conn.close()
	except:
		addr = ""
        
s.close()
