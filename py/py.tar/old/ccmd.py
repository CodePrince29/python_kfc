#! /usr/bin/env python
# ccmd.py      cliente para ejecutar comandos
#
from socket import *
import os
import cgi
import string
import scan
import fmt

# define global variables
REPDIR="/usr/fms/op/rpts/"
HOST = '192.168.101.254'
PORT = 4000

def exe_excel( filename, p_dia ):
   newname = filename + "/" + p_dia
   datafile = REPDIR + filename + "/" + p_dia
   try: 
      f = open(datafile)  # checa si existe
      f.close() 
      print "<h4>" + newname + "</h4>"
      # 
      # intenta abrirlo utilizando un proceso hijo
      # 
      h = os.fork()
      if ( h == 0 ):
         s = socket(AF_INET, SOCK_STREAM)
         s.connect(HOST, PORT)
         s.send('excel ' + newname)
         data = s.recv(1024)
         s.close()
   except:
      print '<h4>No hay datos para ' + newname + '</h4>'

def genera_html( lista, p_dia ):
   print "Content-type: text/html\n"
   print """<html><head></head><body bgcolor="#FFFFFF">"""
   if len(lista):
      for j in lista:
         exe_excel( j, p_dia )
   else:
      print "<h1>No hay datos para la Hoja de calculo</h1>"

   print """</body></html>"""

#
# main
#
form = cgi.FieldStorage()
p_dia = form["diaActual"].value
lista = string.split(form["txtReporte"].value,':')

#p_dia = "04-03-06"
#lista = [ "sales" ]
genera_html( lista, p_dia )
