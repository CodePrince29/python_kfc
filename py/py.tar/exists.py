#!/usr/bin/env python
#
# exists.py
#
import os.path
import time

def newerThan( f, p_dias ):
   if os.path.getmtime(f) > (time.time() - p_dias * 24 * 60 * 60):
      return 1
   else:
      return 0

def exists( f ):
   try:
      n = os.path.getsize( f )
      if n > 0 :
         return 1
      else:
         return 0
   except:
      return 0


#while 1 :
#   filename = raw_input("File: ")
#   print filename
#   if len(filename) == 0: break
#   if exists(filename) > 0:
#      print "Ok existe"
#      if newerThan( filename, 1 ):
#         print "modificado hoy"
#      else:
#         print "modificado antes de hoy "
#   else:
#      print "No existe"
#
